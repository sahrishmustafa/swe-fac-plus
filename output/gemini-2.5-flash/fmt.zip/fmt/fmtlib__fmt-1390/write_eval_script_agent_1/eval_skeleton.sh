#!/bin/bash
set -uxo pipefail

# Navigate to the repository root as operations like git checkout from a specific path require it.
cd /testbed

# Ensure the target test file is in its original state before applying any patch.
# This resets it to the state at the target commit SHA, undoing any previous changes.
git checkout d6eede9e085f0b36edcf0a2f6dff5f7875181019 "test/format-test.cc"

# Required: apply test patch to update target tests (if any).
# The actual content of the patch will be inserted here by the system.
git apply -v - <<'EOF_114329324912'
[CONTENT OF TEST PATCH]
EOF_114329324912

# Required: rebuild the project to include any changes from the patch in the test executables.
# The Dockerfile configured and built the project in the 'build' directory.
# Navigate into the pre-existing build directory to rebuild.
cd build
cmake --build .

# Execute target tests using ctest.
# We use the -R (regex) option to run only the tests corresponding to the specified file.
# "test/format-test.cc" compiles into a test executable named "format-test".
# --output-on-failure ensures that test output is only shown if a test fails, keeping the log clean for successful runs.
ctest --output-on-failure -R "(format-test)"
rc=$? # Capture the exit code of the test command immediately.

echo "OMNIGRIL_EXIT_CODE=$rc" # Required: Echo the captured exit code for result parsing.

# Cleanup: Revert changes made by the patch to the target test files.
# Navigate back to the repository root first to ensure `git checkout` operates correctly on paths relative to the root.
cd /testbed
git checkout d6eede9e085f0b36edcf0a2f6dff5f7875181019 "test/format-test.cc"