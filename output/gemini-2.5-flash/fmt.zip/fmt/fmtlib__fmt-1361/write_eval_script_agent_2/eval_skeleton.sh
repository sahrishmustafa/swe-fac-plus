#!/bin/bash
set -uxo pipefail

# Navigate to the repository root
cd /testbed

# Ensure the target test files are in their original state before applying any patch
# Using the commit SHA provided: a5abe5d95cb8a8015913be9748a9661f3e1fbda8
git checkout a5abe5d95cb8a8015913be9748a9661f3e1fbda8 "test/format-impl-test.cc" "test/grisu-test.cc"

# Required: apply test patch to update target tests (if any)
git apply -v - <<'EOF_114329324912'
[CONTENT OF TEST PATCH]
EOF_114329324912

# Create and navigate to the build directory for out-of-source build
mkdir -p build
cd build

# Configure CMake with required options using existing environment variables set in Dockerfile
# IMPORTANT: Explicitly specify Ninja generator to ensure 'build.ninja' is created.
echo "Configuring CMake for fmtlib/fmt using Ninja generator..."
cmake -G "Ninja" \
      -DCMAKE_BUILD_TYPE=${BUILD} \
      -DFMT_PEDANTIC=ON \
      -DFMT_WERROR=ON \
      -DCMAKE_CXX_STANDARD=${STANDARD} \
      -DCMAKE_CXX_COMPILER=${COMPILER} \
      ..

# Rebuild the project including tests after applying the patch.
# Use ninja for faster parallel builds, as suggested by the Dockerfile which installs ninja-build.
echo "Rebuilding project after applying patch to include updated tests..."
ninja -j$(nproc)

# Execute only the specified target tests using ctest.
# Test names are derived from the filenames (e.g., test/format-impl-test.cc -> format-impl-test).
# Combine both tests into a single ctest command using regex.
echo "Running target tests: format-impl-test and grisu-test"
ctest --output-on-failure -R "(format-impl-test|grisu-test)"
rc=$? # Capture exit code immediately after running tests

echo "OMNIGRIL_EXIT_CODE=$rc" # Required, echo test status

# Cleanup: Revert changes made by the patch to the target test files
# Navigate back to the repository root first
cd /testbed
git checkout a5abe5d95cb8a8015913be9748a9661f3e1fbda8 "test/format-impl-test.cc" "test/grisu-test.cc"