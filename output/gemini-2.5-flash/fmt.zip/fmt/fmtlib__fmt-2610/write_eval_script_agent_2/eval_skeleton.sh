#!/bin/bash
set -uxo pipefail
cd /testbed

# Ensure the target test files are in their original state before applying any patch
# Using the exact commit SHA for checkout, corrected as per feedback
git checkout 19cac63fe4b4d8fe6a4ced28de16a68659cf9035 "test/compile-error-test/CMakeLists.txt" "test/core-test.cc"

# Required: apply test patch to update target tests
git apply -v - <<'EOF_114329324912'
[CONTENT OF TEST PATCH]
EOF_114329324912

# Navigate into the pre-built build directory. The Dockerfile already built the project.
cd build

# Set environment variable for CTest output to show details on failure
export CTEST_OUTPUT_ON_FAILURE=True

# Execute tests using CTest.
# As per the collected information, a single `ctest --output-on-failure` command
# from the build directory will run both 'core-test' (derived from test/core-test.cc)
# and the compile-error tests (defined in test/compile-error-test/CMakeLists.txt
# and integrated into the CTest suite via CMake's build-and-test mechanism).
ctest --output-on-failure
rc=$? # Capture exit code immediately after running tests

echo "OMNIGRIL_EXIT_CODE=$rc" # Required, echo test status

# Cleanup: Revert changes made by the patch to the target test files
cd /testbed # Ensure we are in the repository root for git checkout
# Using the exact commit SHA for checkout, corrected as per feedback
git checkout 19cac63fe4b4d8fe6a4ced28de16a68659cf9035 "test/compile-error-test/CMakeLists.txt" "test/core-test.cc"