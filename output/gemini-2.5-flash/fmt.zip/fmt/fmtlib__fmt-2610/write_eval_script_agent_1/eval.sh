#!/bin/bash
set -uxo pipefail
cd /testbed

# Ensure the target test files are in their original state before applying any patch
# Using the exact commit SHA for checkout
git checkout 19cac63fe4b4d8fe6a6ced28de16a68659cf9035 "test/compile-error-test/CMakeLists.txt" "test/core-test.cc"

# Required: apply test patch to update target tests
git apply -v - <<'EOF_114329324912'
diff --git a/test/compile-error-test/CMakeLists.txt b/test/compile-error-test/CMakeLists.txt
--- a/test/compile-error-test/CMakeLists.txt
+++ b/test/compile-error-test/CMakeLists.txt
@@ -67,6 +67,12 @@ expect_compile_error("
   fmt::format(\"{}\", S());
 ")
 
+# Formatting a function
+expect_compile_error("
+  void (*f)();
+  fmt::format(\"{}\", f);
+")
+
 # Make sure that compiler features detected in the header
 # match the features detected in CMake.
 if (SUPPORTS_USER_DEFINED_LITERALS)
diff --git a/test/core-test.cc b/test/core-test.cc
--- a/test/core-test.cc
+++ b/test/core-test.cc
@@ -770,6 +770,13 @@ TEST(core_test, is_formattable) {
   static_assert(!fmt::is_formattable<unsigned char*, wchar_t>::value, "");
   static_assert(!fmt::is_formattable<const signed char*, wchar_t>::value, "");
   static_assert(!fmt::is_formattable<const unsigned char*, wchar_t>::value, "");
+
+  static_assert(!fmt::is_formattable<void (*)()>::value, "");
+
+  struct s;
+
+  static_assert(!fmt::is_formattable<int(s::*)>::value, "");
+  static_assert(!fmt::is_formattable<int (s::*)()>::value, "");
 }
 
 TEST(core_test, format) { EXPECT_EQ(fmt::format("{}", 42), "42"); }
EOF_114329324912

# Navigate into the pre-built build directory
cd build

# Set environment variable for CTest output
export CTEST_OUTPUT_ON_FAILURE=True

# Run all tests using CTest. This includes 'core-test' and the compile-error tests
# as structured by fmtlib's CMake test setup.
ctest --output-on-failure
rc=$? # Capture exit code immediately after running tests

echo "OMNIGRIL_EXIT_CODE=$rc" # Required, echo test status

# Cleanup: Revert changes made by the patch to the target test files
cd /testbed # Ensure we are in the repository root for git checkout
git checkout 19cac63fe4b4d8fe6a6ced28de16a68659cf9035 "test/compile-error-test/CMakeLists.txt" "test/core-test.cc"