#!/bin/bash
set -uxo pipefail

# Dockerfile leaves the working directory at /testbed/build.
# Navigate to the repository root for git operations (checkout/apply patch).
cd /testbed

# Ensure the target test file is in its original state before applying any patch.
# This prevents issues if a previous run failed or left the file modified.
git checkout 7612f18dc8e0112e64e0845a1ebe9da6cfb8a123 "test/format-test.cc"

# Required: apply test patch to update target tests (if any).
# The content of the patch will be inserted here programmatically.
git apply -v - <<'EOF_114329324912'
[CONTENT OF TEST PATCH]
EOF_114329324912

# Navigate into the pre-existing build directory created and configured by the Dockerfile.
cd build

# Build the project (including tests). The Dockerfile only ran `cmake`,
# `make` is required to compile the source and produce test executables.
make -j$(nproc)

# Execute target tests using ctest.
# The context indicates that `test/format-test.cc` corresponds to a ctest test named "format-test".
ctest --output-on-failure -R "format-test"
rc=$? # Capture the exit code immediately after running tests

echo "OMNIGRIL_EXIT_CODE=$rc" # Required: Echo the test status for evaluation

# Cleanup: Revert changes made by the patch to the target test file.
# Navigate back to the repository root first.
cd /testbed
git checkout 7612f18dc8e0112e64e0845a1ebe9da6cfb8a123 "test/format-test.cc"