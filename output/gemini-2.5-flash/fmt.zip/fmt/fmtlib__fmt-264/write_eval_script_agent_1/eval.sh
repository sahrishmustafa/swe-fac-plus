#!/bin/bash
set -uxo pipefail
cd /testbed

# Ensure the target test file is at the specified commit SHA before applying any patch.
# This step ensures a clean state in case previous runs left modifications.
git checkout 97e9ed11bce828235a25e2cb72910fa6928ffdf5 "test/CMakeLists.txt"

# Apply the test patch to the relevant configuration file.
# The actual patch content will be programmatically inserted here.
git apply -v - <<'EOF_114329324912'
diff --git a/test/CMakeLists.txt b/test/CMakeLists.txt
--- a/test/CMakeLists.txt
+++ b/test/CMakeLists.txt
@@ -10,12 +10,6 @@ function (target_link_cppformat target)
   endif ()
 endfunction ()
 
-function (fmt_target_include_directories)
-  if (CMAKE_MAJOR_VERSION VERSION_GREATER 2.8.10)
-    target_include_directories(${ARGN})
-  endif ()
-endfunction ()
-
 # We compile Google Test ourselves instead of using pre-compiled libraries.
 # See the Google Test FAQ "Why is it not recommended to install a
 # pre-compiled copy of Google Test (for example, into /usr/local)?"
@@ -24,7 +18,7 @@ endfunction ()
 add_library(gmock STATIC
   ${FMT_GMOCK_DIR}/gmock-gtest-all.cc ${FMT_GMOCK_DIR}/gmock/gmock.h
   ${FMT_GMOCK_DIR}/gtest/gtest.h ${FMT_GMOCK_DIR}/gtest/gtest-spi.h)
-fmt_target_include_directories(gmock INTERFACE ${FMT_GMOCK_DIR})
+target_include_directories(gmock INTERFACE ${FMT_GMOCK_DIR})
 find_package(Threads)
 if (Threads_FOUND)
   target_link_libraries(gmock ${CMAKE_THREAD_LIBS_INIT})
@@ -43,7 +37,7 @@ check_cxx_source_compiles("
 check_cxx_source_compiles("
   #include <initializer_list>
   int main() {}" FMT_INITIALIZER_LIST)
-  
+
 if (NOT FMT_VARIADIC_TEMPLATES OR NOT FMT_INITIALIZER_LIST)
   add_definitions(-DGTEST_LANG_CXX11=0)
 endif ()
EOF_114329324912

# Since test/CMakeLists.txt has been modified, a full clean rebuild is required.
# This ensures that CMake re-generates the build system with the patch applied
# and then recompiles the tests accordingly.
echo "--- Reconfiguring and rebuilding after patch application ---"
rm -rf build # Remove existing build directory to ensure a clean re-configuration
cmake -B build -DCMAKE_BUILD_TYPE=Release . # Reconfigure CMake for Release build type
cmake --build build # Perform a full clean build, including tests

# Execute the tests using CTest.
# The 'ctest --output-on-failure' command will discover and run all tests
# as defined in the (possibly patched) test/CMakeLists.txt.
echo "--- Running tests ---"
cd build
ctest --output-on-failure
rc=$? # Capture the exit code immediately after test execution

# Report the overall test result based on the CTest execution outcome.
echo "OMNIGRIL_EXIT_CODE=$rc"

# Clean up: revert changes made by the patch to the target test file.
# This ensures the repository is in a clean state after the evaluation.
cd /testbed
git checkout 97e9ed11bce828235a25e2cb72910fa6928ffdf5 "test/CMakeLists.txt"