#!/bin/bash
set -uxo pipefail
cd /testbed

# Ensure the target test file is at the specified commit SHA before applying any patch
git checkout 88f4be3d19364a484431309f750535386c7d0d5c "test/util-test.cc"

# Apply the test patch to the relevant files
git apply -v - <<'EOF_114329324912'
[CONTENT OF TEST PATCH]
EOF_114329324912

# Execute the specified target test file using CTest.
# CTEST_OUTPUT_ON_FAILURE=1 ensures detailed output for failures.
# -R util-test restricts CTest to run only the test executable associated with test/util-test.cc.
# The `make -j$(nproc)` command in the Dockerfile would have compiled the 'util-test' executable
# inside the 'build/bin' directory, and 'ctest' located in 'build' directory will find it.
cd build && CTEST_OUTPUT_ON_FAILURE=1 ctest -R util-test
rc=$?

echo "OMNIGRIL_EXIT_CODE=$rc"

# Clean up: revert changes made by the patch to the target test file
cd /testbed
git checkout 88f4be3d19364a484431309f750535386c7d0d5c "test/util-test.cc"