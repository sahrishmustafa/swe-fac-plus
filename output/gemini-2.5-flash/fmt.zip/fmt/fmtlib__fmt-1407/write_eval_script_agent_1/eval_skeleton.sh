#!/bin/bash
set -uxo pipefail

# Navigate to the repository root as operations like git checkout from a specific path require it.
cd /testbed

# Ensure the target test files are in their original state before applying any patch.
# This resets them to the state at the target commit SHA, undoing any previous changes (e.g., from prior patch applications).
git checkout 1f918159edded99c9c0cf005c96ecc12e4cc92b1 "test/core-test.cc" "test/format-test.cc"

# Required: apply test patch to update target tests (if any).
# The actual content of the patch will be inserted here by the system.
git apply -v - <<'EOF_114329324912'
[CONTENT OF TEST PATCH]
EOF_114329324912

# Required: rebuild the project to include any changes from the patch in the test executables.
# The Dockerfile configured and built the project in the 'build' directory.
# This command ensures that any new or modified test source files from the patch are compiled.
cmake --build build

# Navigate into the pre-existing build directory created by the Dockerfile to run tests.
cd build

# Execute target tests using ctest.
# We use the -R (regex) option to run only the tests corresponding to the specified files:
# "test/core-test.cc" and "test/format-test.cc" compile into test executables named "core-test" and "format-test" respectively.
# --output-on-failure ensures that test output is only shown if a test fails, keeping the log clean for successful runs.
ctest --output-on-failure -R "(core-test|format-test)"
rc=$? # Capture the exit code of the test command immediately.

echo "OMNIGRIL_EXIT_CODE=$rc" # Required: Echo the captured exit code for result parsing.

# Cleanup: Revert changes made by the patch to the target test files.
# Navigate back to the repository root first to ensure `git checkout` operates correctly on paths relative to the root.
cd /testbed
git checkout 1f918159edded99c9c0cf005c96ecc12e4cc92b1 "test/core-test.cc" "test/format-test.cc"