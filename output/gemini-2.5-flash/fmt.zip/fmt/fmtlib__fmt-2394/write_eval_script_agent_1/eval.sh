#!/bin/bash
set -uxo pipefail
cd /testbed

# Ensure the target test file is in its original state before applying any patch
git checkout cfc05e05f08dc0b6fe619831c96f00ee27d99613 "test/color-test.cc"

# Required: apply test patch to update target tests
git apply -v - <<'EOF_114329324912'
diff --git a/test/color-test.cc b/test/color-test.cc
--- a/test/color-test.cc
+++ b/test/color-test.cc
@@ -20,10 +20,16 @@ TEST(color_test, format) {
       fmt::format(fg(fmt::color::blue) | bg(fmt::color::red), "two color"),
       "\x1b[38;2;000;000;255m\x1b[48;2;255;000;000mtwo color\x1b[0m");
   EXPECT_EQ(fmt::format(fmt::emphasis::bold, "bold"), "\x1b[1mbold\x1b[0m");
+  EXPECT_EQ(fmt::format(fmt::emphasis::faint, "faint"), "\x1b[2mfaint\x1b[0m");
   EXPECT_EQ(fmt::format(fmt::emphasis::italic, "italic"),
             "\x1b[3mitalic\x1b[0m");
   EXPECT_EQ(fmt::format(fmt::emphasis::underline, "underline"),
             "\x1b[4munderline\x1b[0m");
+  EXPECT_EQ(fmt::format(fmt::emphasis::blink, "blink"), "\x1b[5mblink\x1b[0m");
+  EXPECT_EQ(fmt::format(fmt::emphasis::reverse, "reverse"),
+            "\x1b[7mreverse\x1b[0m");
+  EXPECT_EQ(fmt::format(fmt::emphasis::conceal, "conceal"),
+            "\x1b[8mconceal\x1b[0m");
   EXPECT_EQ(fmt::format(fmt::emphasis::strikethrough, "strikethrough"),
             "\x1b[9mstrikethrough\x1b[0m");
   EXPECT_EQ(
EOF_114329324912

# Build system setup
# 1. Create the build directory
mkdir build

# 2. Navigate into the build directory
cd build

# 3. Configure CMake
cmake -DCMAKE_BUILD_TYPE=Release \
      -DCMAKE_CXX_STANDARD=17 \
      -DFMT_DOC=OFF \
      -DCMAKE_CXX_VISIBILITY_PRESET=hidden \
      -DCMAKE_VISIBILITY_INLINES_HIDDEN=ON \
      -DFMT_PEDANTIC=ON \
      -DFMT_WERROR=ON \
      ..

# 4. Build the project
cmake --build . --config Release --parallel "$(nproc)"

# Test execution
# Set environment variable for CTest output
export CTEST_OUTPUT_ON_FAILURE=True

# Run specific tests for test/color-test.cc using CTest's regex filtering
ctest -C Release -R "color-test"
rc=$? # Capture exit code immediately after running tests

echo "OMNIGRIL_EXIT_CODE=$rc" # Required, echo test status

# Cleanup: Revert changes made by the patch to the target test file
cd /testbed # Ensure we are in the repository root for git checkout
git checkout cfc05e05f08dc0b6fe619831c96f00ee27d99613 "test/color-test.cc"