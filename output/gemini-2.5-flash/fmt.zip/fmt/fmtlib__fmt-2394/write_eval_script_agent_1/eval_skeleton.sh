#!/bin/bash
set -uxo pipefail
cd /testbed

# Ensure the target test file is in its original state before applying any patch
git checkout cfc05e05f08dc0b6fe619831c96f00ee27d99613 "test/color-test.cc"

# Required: apply test patch to update target tests
git apply -v - <<'EOF_114329324912'
[CONTENT OF TEST PATCH]
EOF_114329324912

# Build system setup
# 1. Create the build directory
mkdir build

# 2. Navigate into the build directory
cd build

# 3. Configure CMake
cmake -DCMAKE_BUILD_TYPE=Release \
      -DCMAKE_CXX_STANDARD=17 \
      -DFMT_DOC=OFF \
      -DCMAKE_CXX_VISIBILITY_PRESET=hidden \
      -DCMAKE_VISIBILITY_INLINES_HIDDEN=ON \
      -DFMT_PEDANTIC=ON \
      -DFMT_WERROR=ON \
      ..

# 4. Build the project
cmake --build . --config Release --parallel "$(nproc)"

# Test execution
# Set environment variable for CTest output
export CTEST_OUTPUT_ON_FAILURE=True

# Run specific tests for test/color-test.cc using CTest's regex filtering
ctest -C Release -R "color-test"
rc=$? # Capture exit code immediately after running tests

echo "OMNIGRIL_EXIT_CODE=$rc" # Required, echo test status

# Cleanup: Revert changes made by the patch to the target test file
cd /testbed # Ensure we are in the repository root for git checkout
git checkout cfc05e05f08dc0b6fe619831c96f00ee27d99613 "test/color-test.cc"